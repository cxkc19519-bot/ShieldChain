"""Core application infrastructure."""
